package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.training.business.bean.MaterialTypeBean;
import com.training.service.MaterialTypeService;

@SpringBootTest
@ActiveProfiles("test")
public class MaterialTypeServiceTest {

    @Autowired
    private MaterialTypeService materialTypeService;

    @Test
    public void notNullMaterialTypeServiceTest() {

        assertNotNull(materialTypeService);
    }

    @Test
    public void getMaterialTypesTest() {

        List<MaterialTypeBean> materialTypes =
                materialTypeService.getMaterialTypes();

        assertNotNull(materialTypes);
        assertEquals(7, materialTypes.size());
    }

    @Test
    public void getMaterialTypesBasedOnCategoryIdTest() {

        List<MaterialTypeBean> materialTypes =
                materialTypeService
                        .getMaterialTypesBasedOnCategoryId("C001");

        assertNotNull(materialTypes);
        assertEquals(2, materialTypes.size());

        for (MaterialTypeBean materialType : materialTypes) {
            assertEquals("C001", materialType.getCategoryId());
        }
    }
}