package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.training.business.bean.UnitBean;
import com.training.service.UnitService;

@SpringBootTest
@ActiveProfiles("test")
public class UnitServiceTest {

    @Autowired
    private UnitService unitService;

    @Test
    public void notNullUnitServiceTest() {

        assertNotNull(unitService);
    }

    @Test
    public void getUnitsTest() {

        List<UnitBean> units = unitService.getUnits();

        assertNotNull(units);
        assertEquals(5, units.size());
    }

    @Test
    public void getUnitsBasedOnCategoryIdTest() {

        List<UnitBean> units =
                unitService.getUnitsBasedOnCategoryId("C001");

        assertNotNull(units);
        assertEquals(2, units.size());

        for (UnitBean unit : units) {
            assertEquals("C001", unit.getCategoryId());
        }
    }
}