package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.business.bean.MaterialTypeBean;
import com.training.controller.MaterialTypeContoller;
import com.training.service.MaterialTypeService;

@WebMvcTest(MaterialTypeContoller.class)
public class MaterialTypeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MaterialTypeService materialTypeService;

    @Test
    public void getTypeDetailsTest() throws Exception {

        MaterialTypeBean type =
                new MaterialTypeBean("T001", "Silk", "C001");

        when(materialTypeService.getMaterialTypes())
                .thenReturn(Collections.singletonList(type));

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/type/controller/getTypeDetails"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].typeId").value("T001"))
                .andExpect(jsonPath("$[0].typeName").value("Silk"))
                .andExpect(jsonPath("$[0].categoryId").value("C001"));
    }

    @Test
    public void getTypesBasedOnCategoryIdTest() throws Exception {

        MaterialTypeBean type =
                new MaterialTypeBean("T001", "Silk", "C001");

        when(materialTypeService.getMaterialTypesBasedOnCategoryId("C001"))
                .thenReturn(Collections.singletonList(type));

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/type/controller/getTypeDetailsByCategoryId/C001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].typeId").value("T001"))
                .andExpect(jsonPath("$[0].categoryId").value("C001"));
    }
}