package com.training.test.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.training.dao.UnitDAO;
import com.training.entity.UnitEntity;

@SpringBootTest
@ActiveProfiles("test")
public class UnitDAOTest {

    @Autowired
    private UnitDAO unitDAO;

    @Test
    public void notNullUnitDAOTest() {

        assertNotNull(unitDAO);
    }

    @Test
    public void findAllUnitsTest() {

        List<UnitEntity> units = unitDAO.findAll();

        assertNotNull(units);
        assertEquals(5, units.size());
    }

    @Test
    public void findUnitsByCategoryIdTest() {

        List<UnitEntity> units =
                unitDAO.findByMaterialCategoryEntityCategoryId("C001");

        assertNotNull(units);
        assertEquals(2, units.size());

        for (UnitEntity unit : units) {
            assertEquals(
                    "C001",
                    unit.getMaterialCategoryEntity().getCategoryId());
        }
    }
}