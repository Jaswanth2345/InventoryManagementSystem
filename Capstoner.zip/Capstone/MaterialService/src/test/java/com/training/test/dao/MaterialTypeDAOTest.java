package com.training.test.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.training.dao.MaterialTypeDAO;
import com.training.entity.MaterialTypeEntity;

@SpringBootTest
@ActiveProfiles("test")
public class MaterialTypeDAOTest {

    @Autowired
    private MaterialTypeDAO materialTypeDAO;

    @Test
    public void notNullMaterialTypeDAOTest() {

        assertNotNull(materialTypeDAO);
    }

    @Test
    public void findAllMaterialTypesTest() {

        List<MaterialTypeEntity> materialTypes =
                materialTypeDAO.findAll();

        assertNotNull(materialTypes);
        assertEquals(7, materialTypes.size());
    }

    @Test
    public void findMaterialTypesByCategoryIdTest() {

        List<MaterialTypeEntity> materialTypes =
                materialTypeDAO
                        .findByMaterialCategoryEntityCategoryId("C001");

        assertNotNull(materialTypes);
        assertEquals(2, materialTypes.size());

        for (MaterialTypeEntity materialType : materialTypes) {
            assertEquals(
                    "C001",
                    materialType
                            .getMaterialCategoryEntity()
                            .getCategoryId());
        }
    }
}