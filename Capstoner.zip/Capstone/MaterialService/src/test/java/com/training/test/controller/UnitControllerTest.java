package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.training.business.bean.UnitBean;
import com.training.controller.UnitController;
import com.training.service.UnitService;

@WebMvcTest(UnitController.class)
public class UnitControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UnitService unitService;

    @Test
    public void getUnitDetailsTest() throws Exception {

        UnitBean unit = new UnitBean("U001", "Metres", "C001");

        when(unitService.getUnits())
                .thenReturn(Collections.singletonList(unit));

        mockMvc.perform(get("/unit/controller/getUnitDetails"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].unitId").value("U001"))
                .andExpect(jsonPath("$[0].unitName").value("Metres"))
                .andExpect(jsonPath("$[0].categoryId").value("C001"));
    }

    @Test
    public void getUnitsByCategoryIdTest() throws Exception {

        UnitBean unit = new UnitBean("U001", "Metres", "C001");

        when(unitService.getUnitsBasedOnCategoryId("C001"))
                .thenReturn(Collections.singletonList(unit));

        mockMvc.perform(
                get("/unit/controller/getUnitsByCategoryId/C001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].unitId").value("U001"))
                .andExpect(jsonPath("$[0].unitName").value("Metres"))
                .andExpect(jsonPath("$[0].categoryId").value("C001"));
    }
}