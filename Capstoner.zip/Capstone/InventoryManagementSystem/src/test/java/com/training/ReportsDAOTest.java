package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.ReportsDAO;
import com.training.dao.ReportsDataAccess;
import com.training.entity.PurchaseEntity;

@ExtendWith(MockitoExtension.class)
 class ReportsDAOTest {

    @Mock
    private ReportsDAO reportsDAO;

    @InjectMocks
    private ReportsDataAccess reportsDataAccess;

    @Test
     void getVendorWisePurchaseDetailsTest() {

        Date fromDate = new Date();
        Date toDate = new Date();

        PurchaseEntity entity = new PurchaseEntity();
        entity.setPurchaseId(101);
        entity.setTransactionId("P_ONL_001");
        entity.setVendorName("Only Vimal");
        entity.setMaterialCategoryId("C001");
        entity.setMaterialTypeId("T001");
        entity.setBrandName("BrandX");
        entity.setUnitId("U001");
        entity.setQuantity(5);
        entity.setPurchaseAmount(500.0);
        entity.setPurchaseDate(fromDate);
        entity.setStatus("SUCCESS");

        when(reportsDAO.getVendorWisePurchaseDetails(
                fromDate, toDate, "Only Vimal"))
                .thenReturn(Collections.singletonList(entity));

        List<PurchaseBean> result =
                reportsDataAccess.getVendorWisePurchaseDetails(
                        fromDate, toDate, "Only Vimal");

        assertNotNull(result);
        assertEquals(1, result.size());

        PurchaseBean purchase = result.get(0);

        assertEquals(101, purchase.getPurchaseId());
        assertEquals("P_ONL_001", purchase.getTransactionId());
        assertEquals("Only Vimal", purchase.getVendorName());
        assertEquals("C001", purchase.getMaterialCategoryId());
        assertEquals("T001", purchase.getMaterialTypeId());
        assertEquals("BrandX", purchase.getBrandName());
        assertEquals("U001", purchase.getUnitId());
        assertEquals(5, purchase.getQuantity());
        assertEquals(500.0, purchase.getPurchaseAmount(), 0.001);
        assertEquals("SUCCESS", purchase.getStatus());
    }

    @Test
     void getVendorWisePurchaseDetailsEmptyListTest() {

        Date fromDate = new Date();
        Date toDate = new Date();

        when(reportsDAO.getVendorWisePurchaseDetails(
                fromDate, toDate, "Unknown Vendor"))
                .thenReturn(Collections.emptyList());

        List<PurchaseBean> result =
                reportsDataAccess.getVendorWisePurchaseDetails(
                        fromDate, toDate, "Unknown Vendor");

        assertNotNull(result);
        assertEquals(0, result.size());
    }
}