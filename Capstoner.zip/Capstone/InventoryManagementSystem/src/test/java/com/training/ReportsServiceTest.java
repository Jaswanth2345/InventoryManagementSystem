package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.ReportsDataAccess;
import com.training.service.ReportsServiceImpl;

@ExtendWith(MockitoExtension.class)
 class ReportsServiceTest {

    @Mock
    private ReportsDataAccess reportsDataAccess;

    @InjectMocks
    private ReportsServiceImpl reportsService;

    @Test
     void getVendorWisePurchaseDetailsTest() {

        Date fromDate = new Date();
        Date toDate = new Date();

        PurchaseBean purchase = new PurchaseBean();
        purchase.setPurchaseId(101);
        purchase.setVendorName("Only Vimal");

        when(reportsDataAccess.getVendorWisePurchaseDetails(
                fromDate, toDate, "Only Vimal"))
                .thenReturn(Collections.singletonList(purchase));

        List<PurchaseBean> result =
                reportsService.getVendorWisePurchaseDetails(
                        fromDate, toDate, "Only Vimal");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Only Vimal", result.get(0).getVendorName());

        verify(reportsDataAccess)
                .getVendorWisePurchaseDetails(
                        fromDate, toDate, "Only Vimal");
    }
}