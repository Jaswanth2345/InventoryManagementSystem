package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.training.business.bean.PurchaseBean;
import com.training.business.bean.VendorWisePurchaseReportBean;
import com.training.service.ReportsService;
import com.training.web.client.MaterialCategoryConsumer;
import com.training.web.client.MaterialTypeConsumer;
import com.training.web.client.UnitServiceConsumer;
import com.training.web.controller.ReportsController;

@ExtendWith(MockitoExtension.class)
 class ReportsControllerTest {

    @Mock
    private ReportsService reportsService;

    @Mock
    private MaterialCategoryConsumer materialCategoryConsumer;

    @Mock
    private MaterialTypeConsumer materialTypeConsumer;

    @Mock
    private UnitServiceConsumer unitServiceConsumer;

    @InjectMocks
    private ReportsController reportsController;

    @Test
     void getPurchaseDetailsTest() throws Exception {

        Date fromDate = new Date();
        Date toDate = new Date();

        VendorWisePurchaseReportBean request =
                new VendorWisePurchaseReportBean(
                        fromDate,
                        toDate,
                        "Only Vimal");

       
        PurchaseBean purchase = new PurchaseBean();
        purchase.setPurchaseId(101);
        purchase.setTransactionId("P_ONL_001");
        purchase.setVendorName("Only Vimal");
        purchase.setMaterialCategoryId("C001");
        purchase.setMaterialTypeId("T001");
        purchase.setUnitId("U001");

        when(reportsService.getVendorWisePurchaseDetails(
                fromDate,
                toDate,
                "Only Vimal"))
                .thenReturn(Collections.singletonList(purchase));

        
        Map<String, String> categoryMap = new HashMap<>();
        categoryMap.put("C001", "Thread");

        Map<String, String> typeMap = new HashMap<>();
        typeMap.put("T001", "Silk");

        Map<String, String> unitMap = new HashMap<>();
        unitMap.put("U001", "Metres");

        when(materialCategoryConsumer.getCategoryMap())
                .thenReturn(categoryMap);

        when(materialTypeConsumer.getCategoryTypeMap())
                .thenReturn(typeMap);

        when(unitServiceConsumer.getUnitMap())
                .thenReturn(unitMap);

               ResponseEntity<List<PurchaseBean>> response =
                reportsController.getPurchaseDetails(request);

       
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        assertEquals(
                "Only Vimal",
                response.getBody().get(0).getVendorName());

       
        assertEquals(
                "Thread",
                response.getBody().get(0).getMaterialCategoryName());

        assertEquals(
                "Silk",
                response.getBody().get(0).getMaterialTypeName());

        assertEquals(
                "Metres",
                response.getBody().get(0).getMaterialUnitName());
    }

    @Test
     void getPurchaseDetailsEmptyListTest() throws Exception {

        Date fromDate = new Date();
        Date toDate = new Date();

        VendorWisePurchaseReportBean request =
                new VendorWisePurchaseReportBean(
                        fromDate,
                        toDate,
                        "Unknown Vendor");

        when(reportsService.getVendorWisePurchaseDetails(
                fromDate,
                toDate,
                "Unknown Vendor"))
                .thenReturn(Collections.emptyList());

        ResponseEntity<List<PurchaseBean>> response =
                reportsController.getPurchaseDetails(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(0, response.getBody().size());
    }
}