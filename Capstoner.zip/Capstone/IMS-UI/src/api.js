import axios from "axios";

export const API_BASE_URL = (
  import.meta.env.VITE_INVENTORY_API_URL || "http://localhost:8081"
).replace(/\/$/, "");

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});

function errorMessage(error) {
  if (axios.isAxiosError(error)) {
    if (!error.response) {
      return `Cannot reach InventoryManagementSystem at ${API_BASE_URL}.`;
    }
    return error.response.data?.message || `Request failed with HTTP ${error.response.status}.`;
  }
  return "Unexpected error while contacting InventoryManagementSystem.";
}

async function callApi(request) {
  try {
    return (await request()).data;
  } catch (error) {
    throw new Error(errorMessage(error));
  }
}

export async function getVendors() {
  const data = await callApi(() => apiClient.get("/vendors"));
  return Array.isArray(data) ? data : data.vendorList || data.vendors || [];
}

export async function getCategories() {
  const data = await callApi(() => apiClient.get("/categories"));
  return Array.isArray(data) ? data : data.materialCategoryList || data.categories || [];
}

export async function getUnitsAndTypes(materialCategoryId) {
  const data = await callApi(() =>
    apiClient.post("/getUnitAndTypeList", { materialCategoryId }),
  );
  return {
    unitList: data.unitList || data.units || [],
    materialTypeList: data.materialTypeList || data.typeList || data.types || [],
  };
}

export async function savePurchase(purchase) {
  const data = await callApi(() => apiClient.post("/addPurchaseDetail", purchase));
  return data.purchase || data.purchaseBean || data;
}

export async function getPurchaseReport(filters) {
  const data = await callApi(() =>
    apiClient.post("/report/controller/getPurchaseDetails", filters),
  );
  return Array.isArray(data) ? data : data.purchaseList || data.purchases || [];
}
