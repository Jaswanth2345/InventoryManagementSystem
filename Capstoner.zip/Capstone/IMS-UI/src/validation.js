export function todayLocal() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60_000;
  return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}

export function yesterdayLocal() {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const offset = yesterday.getTimezoneOffset() * 60_000;
  return new Date(yesterday.getTime() - offset).toISOString().slice(0, 10);
}

export function validatePurchase(form) {
  const errors = {};
  const quantity = Number(form.quantity);
  const amount = Number(form.purchaseAmount);

  if (!form.vendorName) errors.vendorName = "Select a vendor.";
  if (!form.materialCategoryId) errors.materialCategoryId = "Select a material category.";
  if (!form.materialTypeId) errors.materialTypeId = "Select a material type.";
  if (!form.unitId) errors.unitId = "Select a unit.";
  if (!form.brandName.trim()) errors.brandName = "Enter the brand name.";
  if (!Number.isInteger(quantity) || quantity <= 0) {
    errors.quantity = "Quantity must be a whole number greater than zero.";
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    errors.purchaseAmount = "Purchase amount must be greater than zero.";
  }
  if (!form.purchaseDate) {
    errors.purchaseDate = "Select the purchase date.";
  } else if (form.purchaseDate >= todayLocal()) {
    errors.purchaseDate = "Purchase date must be before today.";
  }
  return errors;
}

export function validateReport(filters) {
  const errors = {};
  if (!filters.vendorName) errors.vendorName = "Select a vendor.";
  if (!filters.fromDate) errors.fromDate = "Select the from date.";
  if (!filters.toDate) errors.toDate = "Select the to date.";
  if (filters.fromDate && filters.toDate && filters.fromDate > filters.toDate) {
    errors.toDate = "To date must be on or after the from date.";
  }
  return errors;
}

export function formatDate(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(value));
}

export function formatCurrency(value) {
  if (value === undefined || value === null || value === "") return "-";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(Number(value));
}
