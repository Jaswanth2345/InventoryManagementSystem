import { useEffect, useState } from "react";
import { API_BASE_URL, getCategories, getVendors } from "./api";
import PurchaseEntry from "./components/PurchaseEntry";
import PurchaseReport from "./components/PurchaseReport";

export default function App() {
  const [page, setPage] = useState("home");
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  async function loadReferenceData() {
    setLoading(true);
    setLoadError("");
    try {
      const [vendorData, categoryData] = await Promise.all([
        getVendors(),
        getCategories(),
      ]);
      setVendors(vendorData);
      setCategories(categoryData);
    } catch (error) {
      setLoadError(error.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadReferenceData();
  }, []);

  return (
    <div className="app-container">
      <header>
        <h1>Inventory Management System</h1>
      </header>

      <nav className="navigation" aria-label="Main navigation">
        <button className={page === "home" ? "active" : ""} onClick={() => setPage("home")}>Home</button>
        <button className={page === "entry" ? "active" : ""} onClick={() => setPage("entry")}>Entry</button>
        <button className={page === "report" ? "active" : ""} onClick={() => setPage("report")}>Report</button>
      </nav>

      {loadError && (
        <div className="service-error" role="alert">
          <strong>Services are not available</strong>
          <span>{loadError}</span>
          <button type="button" onClick={loadReferenceData}>Try again</button>
        </div>
      )}

      {page === "home" && (
        <main className="home-page">
          <h2>Problem Statement</h2>
          <p>
            Glory Textiles needs an application to manage inventory details. This application
            focuses on purchasing materials from vendors and maintaining purchase records.
          </p>
          <p className="small-note">Inventory service: {API_BASE_URL}</p>
        </main>
      )}

      {page === "entry" && (
        <main>
          <PurchaseEntry vendors={vendors} categories={categories} referenceLoading={loading} />
        </main>
      )}

      {page === "report" && (
        <main>
          <PurchaseReport vendors={vendors} referenceLoading={loading} />
        </main>
      )}
    </div>
  );
}
