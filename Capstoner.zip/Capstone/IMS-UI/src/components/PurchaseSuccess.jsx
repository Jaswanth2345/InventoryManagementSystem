import { formatCurrency, formatDate } from "../validation";

export default function PurchaseSuccess({ purchase, onAddAnother }) {
  return (
    <section className="page-section success-section">
      <h2>Purchase Success</h2>
      <p className="success-message">Purchase details added successfully.</p>

      <table className="details-table">
        <tbody>
          <tr><th>Transaction ID</th><td>{purchase.transactionId || "-"}</td></tr>
          <tr><th>Purchase ID</th><td>{purchase.purchaseId || "-"}</td></tr>
          <tr><th>Vendor name</th><td>{purchase.vendorName}</td></tr>
          <tr><th>Material</th><td>{purchase.materialTypeName || purchase.materialTypeId}</td></tr>
          <tr><th>Quantity</th><td>{purchase.quantity} {purchase.materialUnitName || purchase.unitId}</td></tr>
          <tr><th>Purchase amount</th><td>{formatCurrency(purchase.purchaseAmount)}</td></tr>
          <tr><th>Purchase date</th><td>{formatDate(purchase.purchaseDate)}</td></tr>
        </tbody>
      </table>

      <button className="primary-button" type="button" onClick={onAddAnother}>
        Add another purchase
      </button>
    </section>
  );
}
