import { useState } from "react";
import { getPurchaseReport } from "../api";
import { formatCurrency, formatDate, validateReport } from "../validation";
import FieldError from "./FieldError";

const emptyFilters = { vendorName: "", fromDate: "", toDate: "" };

export default function PurchaseReport({ vendors, referenceLoading }) {
  const [filters, setFilters] = useState(emptyFilters);
  const [errors, setErrors] = useState({});
  const [records, setRecords] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  function updateField(event) {
    const { name, value } = event.target;
    setFilters((current) => ({ ...current, [name]: value }));
    setErrors((current) => ({ ...current, [name]: undefined }));
  }

  async function viewReport(event) {
    event.preventDefault();
    const nextErrors = validateReport(filters);
    setErrors(nextErrors);
    setMessage("");
    setRecords(null);
    if (Object.keys(nextErrors).length > 0) return;

    setLoading(true);
    try {
      setRecords(await getPurchaseReport(filters));
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="page-section report-section">
      <h2>Vendor-wise Purchase Report</h2>

      <form className="report-form" noValidate onSubmit={viewReport}>
        <div className="report-field">
          <label htmlFor="reportVendor">Vendor name <span>*</span></label>
          <select id="reportVendor" name="vendorName" value={filters.vendorName} onChange={updateField} disabled={referenceLoading || loading}>
            <option value="">Select vendor</option>
            {vendors.map((vendor) => (
              <option key={vendor.vendorId} value={vendor.vendorName}>{vendor.vendorName}</option>
            ))}
          </select>
          <FieldError message={errors.vendorName} />
        </div>

        <div className="report-field">
          <label htmlFor="fromDate">From date <span>*</span></label>
          <input id="fromDate" name="fromDate" type="date" value={filters.fromDate} onChange={updateField} disabled={loading} />
          <FieldError message={errors.fromDate} />
        </div>

        <div className="report-field">
          <label htmlFor="toDate">To date <span>*</span></label>
          <input id="toDate" name="toDate" type="date" min={filters.fromDate} value={filters.toDate} onChange={updateField} disabled={loading} />
          <FieldError message={errors.toDate} />
        </div>

        <button className="primary-button report-button" type="submit" disabled={referenceLoading || loading}>
          {loading ? "Loading..." : "View Report"}
        </button>
      </form>

      {message && <p className="error-box" role="alert">{message}</p>}

      {records?.length === 0 && <p className="no-records">No records found</p>}

      {records?.length > 0 && (
        <div className="table-wrapper">
          <table className="report-table">
            <thead>
              <tr>
                <th>Transaction ID</th>
                <th>Purchase date</th>
                <th>Category</th>
                <th>Material type</th>
                <th>Brand</th>
                <th>Quantity</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {records.map((purchase, index) => (
                <tr key={purchase.purchaseId || purchase.transactionId || index}>
                  <td>{purchase.transactionId || "-"}</td>
                  <td>{formatDate(purchase.purchaseDate)}</td>
                  <td>{purchase.materialCategoryName || purchase.materialCategoryId}</td>
                  <td>{purchase.materialTypeName || purchase.materialTypeId}</td>
                  <td>{purchase.brandName}</td>
                  <td>{purchase.quantity} {purchase.materialUnitName || purchase.unitId}</td>
                  <td>{formatCurrency(purchase.purchaseAmount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
