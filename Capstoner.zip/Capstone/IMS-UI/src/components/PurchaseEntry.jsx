import { useState } from "react";
import { getUnitsAndTypes, savePurchase } from "../api";
import { validatePurchase, yesterdayLocal } from "../validation";
import FieldError from "./FieldError";
import PurchaseSuccess from "./PurchaseSuccess";

const emptyForm = {
  vendorName: "",
  materialCategoryId: "",
  materialTypeId: "",
  unitId: "",
  brandName: "",
  quantity: "",
  purchaseAmount: "",
  purchaseDate: "",
};

export default function PurchaseEntry({ vendors, categories, referenceLoading }) {
  const [form, setForm] = useState(emptyForm);
  const [types, setTypes] = useState([]);
  const [units, setUnits] = useState([]);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState("");
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedPurchase, setSavedPurchase] = useState(null);

  function updateField(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    setErrors((current) => ({ ...current, [name]: undefined }));
  }

  async function changeCategory(event) {
    const materialCategoryId = event.target.value;
    setForm((current) => ({
      ...current,
      materialCategoryId,
      materialTypeId: "",
      unitId: "",
    }));
    setTypes([]);
    setUnits([]);
    setMessage("");
    setErrors((current) => ({
      ...current,
      materialCategoryId: undefined,
      materialTypeId: undefined,
      unitId: undefined,
    }));

    if (!materialCategoryId) return;

    setLoadingOptions(true);
    try {
      const data = await getUnitsAndTypes(materialCategoryId);
      setTypes(data.materialTypeList);
      setUnits(data.unitList);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoadingOptions(false);
    }
  }

  function clearForm() {
    setForm(emptyForm);
    setTypes([]);
    setUnits([]);
    setErrors({});
    setMessage("");
  }

  async function submitPurchase(event) {
    event.preventDefault();
    const nextErrors = validatePurchase(form);
    setErrors(nextErrors);
    setMessage("");
    if (Object.keys(nextErrors).length > 0) return;

    const requestBody = {
      ...form,
      quantity: Number(form.quantity),
      purchaseAmount: Number(form.purchaseAmount),
    };

    setSaving(true);
    try {
      const saved = await savePurchase(requestBody);
      setSavedPurchase({ ...requestBody, ...saved });
    } catch (error) {
      setMessage(error.message);
    } finally {
      setSaving(false);
    }
  }

  if (savedPurchase) {
    return (
      <PurchaseSuccess
        purchase={savedPurchase}
        onAddAnother={() => {
          setSavedPurchase(null);
          clearForm();
        }}
      />
    );
  }

  return (
    <section className="page-section">
      <h2>Material Purchase Entry</h2>

      <form className="entry-form" noValidate onSubmit={submitPurchase}>
        <div className="form-row">
          <label htmlFor="vendorName">Vendor name <span>*</span></label>
          <div>
            <select id="vendorName" name="vendorName" value={form.vendorName} onChange={updateField} disabled={referenceLoading || saving}>
              <option value="">Select vendor</option>
              {vendors.map((vendor) => (
                <option key={vendor.vendorId} value={vendor.vendorName}>{vendor.vendorName}</option>
              ))}
            </select>
            <FieldError message={errors.vendorName} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="materialCategoryId">Material category <span>*</span></label>
          <div>
            <select id="materialCategoryId" name="materialCategoryId" value={form.materialCategoryId} onChange={changeCategory} disabled={referenceLoading || saving}>
              <option value="">Select category</option>
              {categories.map((category) => (
                <option key={category.categoryId} value={category.categoryId}>{category.categoryName}</option>
              ))}
            </select>
            <FieldError message={errors.materialCategoryId} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="materialTypeId">Material type <span>*</span></label>
          <div>
            <select id="materialTypeId" name="materialTypeId" value={form.materialTypeId} onChange={updateField} disabled={!form.materialCategoryId || loadingOptions || saving}>
              <option value="">{loadingOptions ? "Loading..." : "Select material type"}</option>
              {types.map((type) => (
                <option key={type.typeId} value={type.typeId}>{type.typeName}</option>
              ))}
            </select>
            <FieldError message={errors.materialTypeId} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="unitId">Unit <span>*</span></label>
          <div>
            <select id="unitId" name="unitId" value={form.unitId} onChange={updateField} disabled={!form.materialCategoryId || loadingOptions || saving}>
              <option value="">{loadingOptions ? "Loading..." : "Select unit"}</option>
              {units.map((unit) => (
                <option key={unit.unitId} value={unit.unitId}>{unit.unitName}</option>
              ))}
            </select>
            <FieldError message={errors.unitId} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="brandName">Brand name <span>*</span></label>
          <div>
            <input id="brandName" name="brandName" type="text" maxLength="80" value={form.brandName} onChange={updateField} disabled={saving} />
            <FieldError message={errors.brandName} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="quantity">Quantity <span>*</span></label>
          <div>
            <input id="quantity" name="quantity" type="number" min="1" step="1" value={form.quantity} onChange={updateField} disabled={saving} />
            <FieldError message={errors.quantity} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="purchaseAmount">Purchase amount (₹) <span>*</span></label>
          <div>
            <input id="purchaseAmount" name="purchaseAmount" type="number" min="0.01" step="0.01" value={form.purchaseAmount} onChange={updateField} disabled={saving} />
            <FieldError message={errors.purchaseAmount} />
          </div>
        </div>

        <div className="form-row">
          <label htmlFor="purchaseDate">Purchase date <span>*</span></label>
          <div>
            <input id="purchaseDate" name="purchaseDate" type="date" max={yesterdayLocal()} value={form.purchaseDate} onChange={updateField} disabled={saving} />
            <FieldError message={errors.purchaseDate} />
          </div>
        </div>

        {message && <p className="error-box" role="alert">{message}</p>}

        <div className="form-buttons">
          <button className="secondary-button" type="button" onClick={clearForm} disabled={saving}>Clear</button>
          <button className="primary-button" type="submit" disabled={saving || referenceLoading}>
            {saving ? "Saving..." : "Submit"}
          </button>
        </div>
      </form>
    </section>
  );
}
