# Inventory Management System - React Client

This is a plain React client for UserStory-03: Material Purchase Entry.

## Run on the VM

The InventoryManagementSystem backend and its dependent services must be running first.

```powershell
cd C:\Users\clouduser.AZ-LKM-JAV-01\git\IMS-UI
npm install
npm run dev
```

Open `http://localhost:3001`.

Port 3001 is used because Gitea is already using port 3000. The IMS backend must allow the origin `http://localhost:3001` in its CORS configuration.

## Backend URL

The default backend URL is:

`http://localhost:8081/inventory`

To use another URL, create a `.env.local` file:

```text
VITE_INVENTORY_API_URL=http://localhost:8081/inventory
```

## API calls

- `GET /vendors`
- `GET /categories`
- `POST /getUnitAndTypeList`
- `POST /addPurchaseDetail`
- `POST /report/controller/getPurchaseDetails`

All calls are written in `src/api.js` using Axios. No browser credentials are included.

## Main files

- `src/App.jsx` - page navigation and initial vendor/category loading
- `src/components/PurchaseEntry.jsx` - entry form, dependent dropdowns, save call
- `src/components/PurchaseSuccess.jsx` - saved-purchase confirmation
- `src/components/PurchaseReport.jsx` - vendor/date report and results table
- `src/api.js` - all backend calls
- `src/validation.js` - entry and report validations
- `src/styles.css` - demo-style layout

## Verification

```powershell
npm test
npm run build
```
