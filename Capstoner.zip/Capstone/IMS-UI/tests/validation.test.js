import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { todayLocal, validatePurchase, validateReport } from "../src/validation.js";

const validPurchase = {
  vendorName: "SRS Enterprises",
  materialCategoryId: "1",
  materialTypeId: "2",
  unitId: "3",
  brandName: "Kanchi",
  quantity: "20",
  purchaseAmount: "32000",
  purchaseDate: "2020-10-11",
};

test("a valid purchase has no validation errors", () => {
  assert.deepEqual(validatePurchase(validPurchase), {});
});

test("purchase form validates required and numeric fields", () => {
  const errors = validatePurchase({
    vendorName: "",
    materialCategoryId: "",
    materialTypeId: "",
    unitId: "",
    brandName: "",
    quantity: "0",
    purchaseAmount: "0",
    purchaseDate: "",
  });
  assert.equal(Object.keys(errors).length, 8);
});

test("today is rejected as a purchase date", () => {
  const errors = validatePurchase({ ...validPurchase, purchaseDate: todayLocal() });
  assert.equal(errors.purchaseDate, "Purchase date must be before today.");
});

test("report rejects an inverted date range", () => {
  const errors = validateReport({
    vendorName: "SRS Enterprises",
    fromDate: "2026-09-03",
    toDate: "2026-09-01",
  });
  assert.equal(errors.toDate, "To date must be on or after the from date.");
});

test("all five IMS endpoints are present in the API client", async () => {
  const source = await readFile(new URL("../src/api.js", import.meta.url), "utf8");
  for (const endpoint of [
    "/vendors",
    "/categories",
    "/getUnitAndTypeList",
    "/addPurchaseDetail",
    "/report/controller/getPurchaseDetails",
  ]) {
    assert.match(source, new RegExp(endpoint.replaceAll("/", "\\/")));
  }
});
